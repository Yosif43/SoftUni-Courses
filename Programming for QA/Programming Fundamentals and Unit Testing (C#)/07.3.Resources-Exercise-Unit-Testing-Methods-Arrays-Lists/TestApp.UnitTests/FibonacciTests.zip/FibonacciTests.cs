using NUnit.Framework;

namespace TestApp.UnitTests;

public class FibonacciTests
{
    [Test]
    public void Test_CalculateFibonacci_ZeroInput()
    {
        int result = Fibonacci.CalculateFibonacci(0);
        Assert.AreEqual(0, result, "Fibonacci calculation should return 0 for input 0.");
    }


    [Test]
    [TestCase(1, 1)]
    [TestCase(2, 1)]
    [TestCase(3, 2)]
    [TestCase(4, 3)]
    [TestCase(5, 5)]
    [TestCase(6, 8)]
    public void Test_CalculateFibonacci_PositiveInput(int input, int expected)
    {
        int result = Fibonacci.CalculateFibonacci(input);
        Assert.AreEqual(expected, result);

    }
}